public abstract class FiguraTridimensional {
    final int dimensiones=3;
    //metodos abstractos
    public abstract double calcularVolumen();
    public abstract double calcularSuperficie();

}
